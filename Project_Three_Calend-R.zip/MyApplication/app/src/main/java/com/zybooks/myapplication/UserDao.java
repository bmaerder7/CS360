package com.zybooks.myapplication;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;
@Dao
public interface UserDao {
    @Insert
    void insertUser(User user);

    @Update
    void updateUser(User user);

    @Delete
    void deleteUser(User user);

    //query used to select a user by username AND password
    @Query("SELECT * FROM users WHERE username = :username AND pass = :pass LIMIT 1")
    User login(String username, String pass);

    //query used to select a user by username
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    User getUserByName(String username);
}
