package com.zybooks.myapplication;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ModifyEventActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_CODE = 100;
    private String username;
    private int eventId;
    private CheckBox smsReminderCheckbox;
    private boolean loadingEvent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_modifyevent);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.modifyevent), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //get extras username and eventid for context
        username = getIntent().getStringExtra("username");
        eventId = getIntent().getIntExtra("eventId", -1);

        //if the event exists, load it
        if (eventId != -1) {
            loadEvent(eventId);
        }

        //listen for user to click delete button
        ImageButton deleteEventButton = findViewById(R.id.deleteEventButton);
        deleteEventButton.setOnClickListener(v -> {
            deleteCurrentEvent();
        });

        //listen for user to click save button
        ImageButton saveEventButton = findViewById(R.id.saveEventButton);
        saveEventButton.setOnClickListener(v -> {
            updateCurrentEvent();
        });

        //listens for sms reminder checkbox
        smsReminderCheckbox = findViewById(R.id.smsCheckbox);
        smsReminderCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (!loadingEvent && isChecked) {
                requestSmsPermissionIfNeeded();
            }
        });


    }

    //update event
    private void updateCurrentEvent() {
        //exception handling if for some reason the user has accessed an event that does not exist
        if (eventId == -1) {
            Toast.makeText(this, "No event selected", Toast.LENGTH_SHORT).show();
            return;
        }

        GridLayout grid = findViewById(R.id.modifyEventDisplay);

        //assign string variables with entered text and spinner values from the update fields
        EditText titleCell = grid.findViewWithTag("title");
        Spinner dayCell = grid.findViewWithTag("day");
        Spinner timeCell = grid.findViewWithTag("time");
        EditText descriptionCell = grid.findViewWithTag("description");
        EditText locationCell = grid.findViewWithTag("location");
        String title = titleCell.getText().toString().trim();
        String day = dayCell.getSelectedItem().toString().trim();
        String time = timeCell.getSelectedItem().toString().trim();
        String description = descriptionCell.getText().toString().trim();
        String location = locationCell.getText().toString().trim();
        boolean smsReminder = smsReminderCheckbox.isChecked();

        //exception handling for empty required fields
        if (title.isEmpty() || day.isEmpty() || time.isEmpty()) {
            Toast.makeText(this, "Title, day, and time are required", Toast.LENGTH_SHORT).show();
            return;
        }

        //create new event
        Event updatedEvent = new Event(username, title, day, time, description, location, smsReminder);

        //replace old event
        updatedEvent.setId(eventId);

        //run DAO operations to update database in thread
        new Thread(() -> {
            AppDatabase db = AppDatabase.getInstance(getApplicationContext());
            db.eventDao().updateEvent(updatedEvent);

            //refresh the UI
            runOnUiThread(() -> {
                Toast.makeText(this, "Event Updated", Toast.LENGTH_SHORT).show();
                refreshMainActivity();
            });
        }).start();
    }

    //delete event
    private void deleteCurrentEvent() {
        //exception handling if for some reason the user has accessed an event that does not exist
        if (eventId == -1) {
            Toast.makeText(this, "No event selected", Toast.LENGTH_SHORT).show();
            return;
        }

        //run the DAO delete operation=s in thread to update database
        new Thread(() -> {
            AppDatabase db = AppDatabase.getInstance(getApplicationContext());
            Event event = db.eventDao().getEventById(eventId);
            if (event != null) {
                db.eventDao().deleteEvent(event);

                //refresh the UI
                runOnUiThread(() -> {
                    Toast.makeText(this, "Event deleted", Toast.LENGTH_SHORT).show();
                    refreshMainActivity();
                });
            } else {
                runOnUiThread(() -> {
                    Toast.makeText(this, "Event not found", Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    //loads the current variables into update event fields
    private void loadEvent(int eventId) {
        new Thread(() -> {
            AppDatabase db = AppDatabase.getInstance(getApplicationContext());
            Event event = db.eventDao().getEventById(eventId);

            runOnUiThread(() -> {
                if (event != null) {
                    GridLayout grid = findViewById(R.id.modifyEventDisplay);

                    //loads all the current variables and sets texts and spinners
                    EditText titleCell = grid.findViewWithTag("title");
                    Spinner dayCell = grid.findViewWithTag("day");
                    Spinner timeCell = grid.findViewWithTag("time");
                    EditText descriptionCell = grid.findViewWithTag("description");
                    EditText locationCell = grid.findViewWithTag("location");
                    titleCell.setText(event.getTitle());
                    setSpinnerSelection(dayCell, event.getDay());
                    setSpinnerSelection(timeCell, event.getTime());
                    locationCell.setText(event.getLocation());
                    descriptionCell.setText(event.getDescription());
                    loadingEvent = true;
                    smsReminderCheckbox.setChecked(event.isSmsReminder());
                    loadingEvent = false;

                } else {
                    Toast.makeText(this, "Event not found", Toast.LENGTH_SHORT).show();
                }
            });
        }).start();
    }

    //helper method used above to set the spinner to the current variable
    //using indexing
    private void setSpinnerSelection(Spinner spinner, String value) {
        if (spinner == null || value == null) {
            return;
        }
        for (int i = 0; i < spinner.getCount(); ++i) {
            String item = spinner.getItemAtPosition(i).toString();

            if (item.equals(value)) {
                spinner.setSelection(i);
                return;
            }
        }
    }

    //method used to refresh the UI and update the calendar after deleting or updating events
    private void refreshMainActivity() {
        Intent intent = new Intent(ModifyEventActivity.this, MainActivity.class);
        intent.putExtra("username", username);

        intent.addFlags(intent.FLAG_ACTIVITY_CLEAR_TOP);

        startActivity(intent);
        finish();
    }

    private void requestSmsPermissionIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS reminders enabled", Toast.LENGTH_SHORT).show();
            } else {
                if (smsReminderCheckbox != null) {
                    smsReminderCheckbox.setChecked(false);
                }
            }
        }
    }
}
