package com.zybooks.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CreateAccActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_createacc);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.accCreation), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText usernameEditText = findViewById(R.id.username);
        EditText passwordEditText = findViewById(R.id.password);

        //Listens for the 'Create Account' button to be clicked
        //assigns string variables with user entered fields
        Button createAccountButton = findViewById(R.id.createAccButton);
        createAccountButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            //exception handling for blank fields
            if(username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            //runs database operations in thread
            new Thread(() -> {
                AppDatabase db = AppDatabase.getInstance(getApplicationContext());
                UserDao userDao = db.userDao();

                //checks entered username against those existing in database
                User existingUser = userDao.getUserByName(username);
                if (existingUser != null) {
                    runOnUiThread(() -> {
                        Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
                    });
                    }
                //adds account details to database
                //starts new activity putting extra username for context
                else {
                    User newUser = new User(username, password);
                    userDao.insertUser(newUser);

                    runOnUiThread(() -> {
                        Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(CreateAccActivity.this, MainActivity.class);
                        intent.putExtra("username", username);
                        startActivity(intent);
                        finish();
                    });
                }
            }).start();
        });

        //Listener for 'Back' button
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(CreateAccActivity.this, LoginActivity.class);
            startActivity(intent);
        });
    }
}
