package com.zybooks.myapplication;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface EventDao {
    @Insert
    void insertEvent(Event event);

    @Update
    void updateEvent(Event event);

    @Delete
    void deleteEvent(Event event);

    //query used to select all events of a user
    @Query("SELECT * FROM events WHERE username = :username")
    List<Event> getEventsByUsername(String username);

    //query used to select a singular event
    @Query("SELECT * FROM events WHERE Id = :Id LIMIT 1")
    Event getEventById(int Id);
}
