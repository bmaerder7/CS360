package com.zybooks.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import android.widget.CheckBox;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class AddEventActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_CODE = 100;
    private CheckBox smsReminderCheckbox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_addevent);
        String username = getIntent().getStringExtra("username");
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.addEventScreen), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //listens for sms reminder checkbox
        smsReminderCheckbox = findViewById(R.id.smsReminderCheckbox);
        smsReminderCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                requestSmsPermissionIfNeeded();
            }
        });

        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> {
            finish();
        });

        // add event to grid
        Button saveButton = findViewById(R.id.saveEventButton);
        saveButton.setOnClickListener(v -> {
            EditText titleEditText = findViewById(R.id.eventName);
            EditText descriptionEditText = findViewById(R.id.eventDescription);
            EditText locationEditText = findViewById(R.id.eventLocation);
            Spinner daySpinner = findViewById(R.id.dateSpinner);
            Spinner timeSpinner = findViewById(R.id.timeSpinner);

            String title = titleEditText.getText().toString().trim();
            String description = descriptionEditText.getText().toString().trim();
            String location = locationEditText.getText().toString().trim();
            String day = daySpinner.getSelectedItem().toString();
            String time = timeSpinner.getSelectedItem().toString();
            boolean smsReminder = smsReminderCheckbox.isChecked();

            //exception handling for required fields
            if (title.isEmpty() || day.isEmpty() || time.isEmpty()) {
                Toast.makeText(this, "Please Enter an Event Title, Day, and Time", Toast.LENGTH_SHORT).show();
                return;
            }

            Event event = new Event(username, title, day, time, description, location, smsReminder);

            //execute in thread using DAO
            new Thread(() -> {
                AppDatabase db = AppDatabase.getInstance(getApplicationContext());
                db.eventDao().insertEvent(event);

                runOnUiThread(() -> {
                    Toast.makeText(this, "Event Saved", Toast.LENGTH_SHORT).show();
                    finish();
                });
            }).start();
        });
    }
    private void requestSmsPermissionIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS reminders enabled", Toast.LENGTH_SHORT).show();
            } else {
                if (smsReminderCheckbox != null) {
                    smsReminderCheckbox.setChecked(false);
                }
            }
        }
    }
}
