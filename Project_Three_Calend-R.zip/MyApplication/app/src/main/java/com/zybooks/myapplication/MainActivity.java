package com.zybooks.myapplication;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.activity_main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //gets extra username from previous activity for context
        username = getIntent().getStringExtra("username");

        //load events of the user
        if (username != null) {
            loadEvents(username);
        }

        //listens for user to click 'add event' plus icon
        //starts activity
        ImageButton addEventButton = findViewById(R.id.addEventButton);
        addEventButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddEventActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (username != null) {
            loadEvents(username);
        }
    }

    //loads the events from the database into the grid view
    //loads current day into UI
    private void loadEvents(String username) {
        new Thread(() -> {
            AppDatabase db = AppDatabase.getInstance(getApplicationContext());
            List<Event> events = db.eventDao().getEventsByUsername(username);

            runOnUiThread(() -> {
                LinearLayout banner = findViewById(R.id.topBanner);
                LocalDate today = LocalDate.now();
                DayOfWeek todayDay = today.getDayOfWeek();
                String day = todayDay.toString().trim();
                TextView dateCell = banner.findViewById(R.id.dayOfWeek);
                dateCell.setText(day);

                for (Event event: events) {
                    //creates a tag of day and time that corresponds to tags
                    //assigned to each gridview block based on orientation
                    //(i.e. 'monday_6pm')
                    String tag = event.getDay().trim() + "_" + event.getTime().trim();

                    TextView cell = findViewById(R.id.weekDisplay).findViewWithTag(tag);

                    if (cell != null) {
                        //assign title to the text of the cell with corresponding tag
                        cell.setText(event.getTitle());

                        //listen for a click on any block with an event
                        //start modify event activity
                        cell.setOnClickListener(v -> {
                            Intent intent = new Intent(MainActivity.this, ModifyEventActivity.class);
                            //put extras username and event id for context
                            intent.putExtra("eventId", event.getId());
                            intent.putExtra("username", username);
                            startActivity(intent);
                        });
                    }
                }
                checkUpcomingEvents(events);
            });
        }).start();
    }

    //helper method to take user selected day from spinner to DayOfWeek val
    private DayOfWeek parseDayOfWeek(String day) {
        switch (day.trim().toLowerCase()) {
            case "monday":
                return DayOfWeek.MONDAY;
            case "tuesday":
                return DayOfWeek.TUESDAY;
            case "wednesday":
                return DayOfWeek.WEDNESDAY;
            case "thursday":
                return DayOfWeek.THURSDAY;
            case "friday":
                return DayOfWeek.FRIDAY;
            case "saturday":
                return DayOfWeek.SATURDAY;
            case "sunday":
                return DayOfWeek.SUNDAY;
            default:
                return null;
        }
    }

    //helper method to take user selected time and convert to 24-hour string
    private String parseTime(String time) {
        switch(time.trim().toLowerCase()) {
            case "6am":
                return "6:00";
            case "8am":
                return "8:00";
            case "10am":
                return "10:00";
            case "12pm":
                return "12:00";
            case "2pm":
                return "14:00";
            case "4pm":
                return "16:00";
            case "6pm":
                return "18:00";
            case "8pm":
                return "20:00";
            case "10pm":
                return "22:00";
            default:
                return null;

        }
    }

    //checks upcoming events and notifies if an event is within 2 hours
    private void checkUpcomingEvents(List<Event> events) {
        LocalDateTime now = LocalDateTime.now();
        DayOfWeek currentDay = now.getDayOfWeek();
        LocalTime currentTime = now.toLocalTime();
        for (Event event : events) {
            DayOfWeek eventDay = parseDayOfWeek(event.getDay());
            if (eventDay == currentDay) {
                String eventTimeString = parseTime(event.getTime());
                if (eventTimeString != null) {
                    LocalTime eventTime = LocalTime.parse(eventTimeString);
                    long minutesUntilEvent = Duration.between(currentTime, eventTime).toMinutes();

                    if (minutesUntilEvent >= 0 && minutesUntilEvent <=120) {
                        if (event.isSmsReminder() && !wasSmsSent(event)) {
                            boolean smsAttempted = sendSmsReminder(event, minutesUntilEvent);

                            if (smsAttempted) {
                                markSmsSent(event);
                            }
                        }
                    }
                }
            }
        }
    }

    //creates unique key for each event reminder
    private String getSmsSentKey(Event event) {
        return "sms_sent_" + event.getId() + "_" + LocalDate.now().toString();
    }

    //checks whether event sms was attempted already
    private boolean wasSmsSent(Event event) {
        SharedPreferences preferences = getSharedPreferences("SmsPrefs", MODE_PRIVATE);
        return preferences.getBoolean(getSmsSentKey(event), false);
    }

    //marks event as sent
    private void markSmsSent(Event event) {
        SharedPreferences preferences = getSharedPreferences("SmsPrefs", MODE_PRIVATE);
        preferences.edit().putBoolean(getSmsSentKey(event), true).apply();
    }

    //sends sms reminder to phoneNumber if checkbox is ticked
    //returns boolean to be used to mark reminder as sent
    private boolean sendSmsReminder(Event event, long minutesUntilEvent) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        //phone number assigned to emulator default
        //i tried the listed number on the emulator and this 5554 #(the emulator id)
        //the sms would not go through but my toasts did, confirming functionality of logic
        //but something with the emulator sms is not working or i cant figure it out
        //I tried researching ways to grab a device's number but this contains privacy risks
        //and therefore there were no guides on how to do so
        String phoneNumber = "5554";
        String message = event.getTitle() + " is coming up in " + minutesUntilEvent + " minutes.";
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);

            Toast.makeText(this, "SMS attempted to " + phoneNumber, Toast.LENGTH_SHORT).show();
            return true;
        } catch (Exception e) {
            Toast.makeText(this, "SMS failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return false;
        }
    }

}