package com.zybooks.myapplication;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ForeignKey;
import androidx.room.Index;

//declares username from User as a foreign key
@Entity(
        tableName = "events",
        foreignKeys = @ForeignKey(
                entity = User.class,
                parentColumns = "username",
                childColumns = "username",
                onDelete = ForeignKey.CASCADE
        ),
        indices = {@Index("username")}
)

public class Event {
    //primary key is the id and will be automatically assigned
    @PrimaryKey(autoGenerate = true)
    private int id;

    private String username;
    private String title;
    private String day;
    private String time;
    private String description;
    private String location;
    private boolean smsReminder;

    //constructor
    public Event(String username, String title, String day, String time, String description, String location, boolean smsReminder) {
        this.username = username;
        this.title = title;
        this.day = day;
        this.time = time;
        this.description = description;
        this.location = location;
        this.smsReminder = smsReminder;
    }

    //getters and setters
    public int getId() { return id; }
    public void setId(int Id) { this.id = Id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDay() { return day; }
    public void setDay(String day) { this.day = day; }

    public String getTime() { return time; }

    public void setTime(String time) { this.time = time; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public boolean isSmsReminder() {
        return smsReminder;
    }

    public void setSmsReminder() {
        this.smsReminder = smsReminder;
    }
}
