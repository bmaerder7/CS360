package com.zybooks.myapplication;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;
@Entity(
        tableName = "users",
        indices = {@Index(value = "username", unique = true)}
)
public class User {
    @PrimaryKey(autoGenerate = true)
    private int id;

    private String username;
    private String pass;

    //constructor
    public User(String username,String pass) {
        this.username = username;
        this.pass = pass;
    }

    //getters and setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPass() { return pass; }
    public void setPass(String pass) { this.pass = pass; }
}
